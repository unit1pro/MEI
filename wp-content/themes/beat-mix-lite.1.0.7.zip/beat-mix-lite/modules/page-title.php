<header class="page-header text-center">
	<div class="mask"></div>
	<div class="page-header-bg"></div>
	<div class="page-header-inner">
		<div class="wrapper">
			
			<?php get_template_part('modules/breadcrumb'); ?>
			<!-- breadcrumb -->
		</div>
		<!-- wrapper -->
	</div>
	<!-- page-header-inner -->       
</header>
<!-- page-header -->