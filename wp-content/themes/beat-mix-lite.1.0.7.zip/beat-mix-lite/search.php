<?php

get_header();

get_template_part('modules/blog/blog', 'one-col');

get_footer();

